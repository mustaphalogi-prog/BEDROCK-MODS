package com.bedrockmods.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.Editable
import android.text.TextWatcher

data class Addon(
    val title: String, val category: String, val description: String,
    val image: Int, val url: String, val tag: String
)

class MainActivity : Activity() {
    private val bg = Color.rgb(13, 19, 16)
    private val panel = Color.rgb(25, 35, 29)
    private val green = Color.rgb(139, 234, 87)
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private var selectedCategory = "الكل"
    private val favorites = mutableSetOf<String>()

    private val addons = listOf(
        Addon("FURNICRAFT للأثاث", "الأثاث", "مجموعة كبيرة من الأثاث والديكور التفاعلي لعالمك.", R.drawable.furniture, "https://mcpedl.com/furnicraft-furniture/", "مميز"),
        Addon("More Simple Structures", "الهياكل", "أطلال وأهرامات وهياكل جديدة تظهر أثناء الاستكشاف.", R.drawable.structures, "https://mcpedl.com/?s=More+Simple+Structures", "استكشاف"),
        Addon("Mutant Creatures", "المخلوقات", "مخلوقات متحولة تضيف تحديات جديدة إلى عالمك.", R.drawable.creatures, "https://mcpedl.com/?s=Mutant+Creatures+Bedrock", "مغامرة"),
        Addon("Raiyon's Dynamic Lightning", "السيرفايفر", "إضاءة ديناميكية تساعدك على استكشاف الكهوف.", R.drawable.survival, "https://mcpedl.com/?s=Raiyon%27s+Dynamic+Lightning", "مفيد"),
        Addon("عوالم السحر", "السحر والأساطير", "قسم تجريبي لإضافات السحر والعوالم الخيالية.", R.drawable.magic, "https://mcpedl.com/category/addons/", "قريباً"),
        Addon("مركبات Minecraft", "السيارات", "قسم للمركبات والسيارات المخصصة لنسخة Bedrock.", R.drawable.cars, "https://mcpedl.com/category/addons/", "قريباً"),
        Addon("حزم المظاهر", "التكستشرات", "حزم تغيّر مظهر العالم والكتل والبيئة.", R.drawable.textures, "https://mcpedl.com/category/texture-packs/", "استكشاف")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildScreen()
        render()
    }

    private fun rounded(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(14), dp(16), 0)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        brand.addView(text("BEDROCK", 25f, Color.WHITE, true))
        brand.addView(text("MODS  •  مكتبة إضافاتك", 12f, green, true))
        header.addView(brand)
        val badge = text("B", 22f, bg, true).apply {
            gravity = Gravity.CENTER; background = rounded(green, dp(16).toFloat())
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        }
        header.addView(badge)
        root.addView(header)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(35,85,49), Color.rgb(20,42,31))).apply { cornerRadius = dp(18).toFloat() }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) }
        }
        hero.addView(text("حوّل عالمك إلى مغامرة جديدة", 19f, Color.WHITE, true))
        hero.addView(text("اكتشف إضافات Bedrock واختر ما يناسب عالمك.", 13f, Color.rgb(218,235,220)).apply { setPadding(0, dp(6), 0, 0) })
        root.addView(hero)

        search = EditText(this).apply {
            hint = "ابحث عن مود أو تصنيف..."
            setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE); textSize = 14f
            singleLine = true; setPadding(dp(14), 0, dp(14), 0)
            background = rounded(panel, dp(12).toFloat())
            layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(14) }
        }
        root.addView(search)

        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(12), 0, dp(8)) }
        listOf("الكل","السحر والأساطير","الأثاث","السيرفايفر","السيارات","الهياكل","المخلوقات","التكستشرات").forEach { name ->
            val chip = TextView(this).apply {
                text = name; textSize = 12f; setTextColor(if (name == selectedCategory) bg else Color.WHITE)
                setPadding(dp(14), dp(9), dp(14), dp(9))
                background = rounded(if (name == selectedCategory) green else panel, dp(22).toFloat())
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(7) }
                setOnClickListener { selectedCategory = name; buildScreenRefresh() }
            }
            chips.addView(chip)
        }
        scroll.addView(chips)
        root.addView(scroll)

        val titleRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        titleRow.addView(text("اكتشف الإضافات", 18f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        titleRow.addView(text("صور • تفاصيل • تحميل", 10f, green))
        root.addView(titleRow)

        val contentScroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(24)) }
        contentScroll.addView(list)
        root.addView(contentScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        search.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render() }
            override fun afterTextChanged(s: Editable?) {}
        })
        setContentView(root)
        // Rebuild category chips and preserve the search text when a category is selected.
    }

    private fun buildScreenRefresh() {
        val query = search.text.toString()
        buildScreen()
        search.setText(query)
        render()
    }

    private fun render() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val q = if (::search.isInitialized) search.text.toString().trim() else ""
        val filtered = addons.filter {
            (selectedCategory == "الكل" || it.category == selectedCategory) &&
            (q.isEmpty() || it.title.contains(q, true) || it.category.contains(q, true))
        }
        if (filtered.isEmpty()) {
            list.addView(text("لا توجد نتائج. جرّب كلمة أخرى.", 14f, Color.LTGRAY).apply { setPadding(dp(8), dp(24), 0, dp(24)) })
        }
        filtered.forEach { addon -> list.addView(addonCard(addon)) }
    }

    private fun addonCard(addon: Addon): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, dp(16).toFloat())
            setPadding(dp(10), dp(10), dp(10), dp(12))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
        }
        val image = ImageView(this).apply {
            setImageResource(addon.image); scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.DKGRAY, dp(12).toFloat())
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(-1, dp(164))
        }
        card.addView(image)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, 0) }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        info.addView(text(addon.title, 16f, Color.WHITE, true))
        info.addView(text("${addon.category}  •  ${addon.tag}", 11f, green).apply { setPadding(0, dp(4), 0, 0) })
        row.addView(info)
        val fav = TextView(this).apply {
            text = if (favorites.contains(addon.title)) "♥" else "♡"
            textSize = 25f; setTextColor(green); gravity = Gravity.CENTER
            setOnClickListener { if (!favorites.add(addon.title)) favorites.remove(addon.title); text = if (favorites.contains(addon.title)) "♥" else "♡" }
        }
        row.addView(fav, LinearLayout.LayoutParams(dp(42), dp(42)))
        card.addView(row)
        card.addView(text(addon.description, 12f, Color.LTGRAY).apply { setPadding(0, dp(8), 0, dp(10)) })
        val button = TextView(this).apply {
            text = "عرض صفحة المود  ↗"; textSize = 13f; gravity = Gravity.CENTER
            setTextColor(bg); setTypeface(typeface, Typeface.BOLD)
            background = rounded(green, dp(10).toFloat())
            setPadding(0, dp(12), 0, dp(12))
            setOnClickListener { openPage(addon.url) }
        }
        card.addView(button)
        return card
    }

    private fun openPage(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { Toast.makeText(this, "تعذّر فتح صفحة المود", Toast.LENGTH_SHORT).show() }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
