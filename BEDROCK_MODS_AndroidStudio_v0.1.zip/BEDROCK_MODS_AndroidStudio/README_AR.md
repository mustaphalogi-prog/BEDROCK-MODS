# BEDROCK MODS — Android Studio starter project

This is version 0.1.0: a native Android starter app for browsing Minecraft Bedrock add-ons.

## Open it
1. Install Android Studio on your computer.
2. Choose **Open** and select this `BEDROCK_MODS_AndroidStudio` folder.
3. Let Gradle sync finish.
4. Connect your Android phone with USB debugging enabled, or use an emulator.
5. Press **Run**.

## Current prototype features
- Arabic dark/green interface.
- Search and category filters.
- Favorites for the current app session.
- Seven original voxel-inspired category illustrations bundled locally.
- Add-on cards link to their source pages.

## Important status
- This is source code, not a compiled APK.
- The included category pictures are original illustrative artwork for the prototype, not screenshots of the exact add-ons.
- The starter catalog contains a few source-page links; entries marked "قريباً" are category previews, not downloadable add-ons.
- This version opens the publisher/source page. It does not yet download and import add-on files automatically.
- Before publishing, each catalog entry needs a verified Bedrock file link, creator permission/terms, version compatibility, a real screenshot, and malware/safety checks.
- No firearms or real-world weapon content is included.

## Build output
In Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
